package Milestone1;

import java.text.DecimalFormat;

public class Weapons  extends Salable{
public Weapons(String name, String description, double price, int quantity) {
	super(name, description, price, quantity);
}

public static void ninjaStars() {
	// TODO Auto-generated method stub
	
}

public static void knife() {
	// TODO Auto-generated method stub
	
}


	

}

