package Milestone1;

import java.text.DecimalFormat;

public class Health extends Salable{

	public Health(String name, String description, double price, int quantity) {
		super(name, description, price, quantity);
		// TODO Auto-generated constructor stub
	}

	public static void bandage() {
		// TODO Auto-generated method stub
		
	}

	public static void medic() {
		// TODO Auto-generated method stub
		
	}

	
	
	
	
	
	
	
	
	
}
