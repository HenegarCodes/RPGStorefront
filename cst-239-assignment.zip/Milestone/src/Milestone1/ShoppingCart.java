package Milestone1;
import java.io.IOException;
import java.net.UnknownHostException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

public class ShoppingCart  {

	private static void displayProduct(Salable product) {
		System.out.println(product.getDescription() + " | " + product.getName() + " | $" +
				product.getPrice() +" | " + product.getQuantity());
	}

		
		
		public static void shoppingCart() throws UnknownHostException, IOException {
			int countKnife = 0 + StoreFront.getKnifePurchase();
			int countStar = 0 + StoreFront.getStarPurchase();
			int countChain = 0 + StoreFront.getChainPurchase();
			int countM69 = 0 + StoreFront.getM69Purchase();
			int countBandage = 0 + StoreFront.getBandagePurchase();
			int countMedic = 0 + StoreFront.getMedicPurchase();
	
		
			ArrayList<Salable> cart = new ArrayList<Salable>();
			cart.add(new Weapons("Machete", "Weapon", 50.00, countKnife));
			cart.add(new Weapons("Ninja Star", "Weapon", 10.00, countStar));
			cart.add(new Armor("ChainMail", "Armor", 200.00, countChain));
			cart.add(new Armor("M69", "Armor", 300.00, countChain));
			cart.add(new Health("Bandage", "Health", 100.00, countBandage));
			cart.add(new Health("Medic", "Health", 200.00, countMedic));
		
		System.out.println("Your shopping cart:");
		
		Collections.sort(cart, Salable.quantityComparator);
		
		Iterator<Salable> iterator = cart.iterator();
		while(iterator.hasNext()) {
			displayProduct(iterator.next());
		}
		try {
			Scanner scan = new Scanner(System.in);
			byte select = scan.nextByte();
		
		if(select == 1)
			StoreFront.main(null);
		else
			System.exit(0);
		
		
		
		}catch(InputMismatchException e) {
			StoreFront.main(null);
		}
		}
}


			
			
			
			
			
			
			
			
