package Milestone1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Customer {
	
	
	private Socket customerSocket;
	private PrintWriter out;
	private BufferedReader in;
	
	public void start(String ip, int port) throws UnknownHostException, IOException {
		customerSocket = new Socket(ip, port);
		
		setOut(new PrintWriter(customerSocket.getOutputStream(), true));
		setIn(new BufferedReader(new InputStreamReader(customerSocket.getInputStream())));
	}
	
	public void storefront() throws UnknownHostException, IOException {
		StoreFront.main(null);
	}
	
	public void cleanup() throws IOException {
		customerSocket.close();
	}
	
	
	
	
	
	

	public static void main(String[] args) throws UnknownHostException, IOException 
		{
		// TODO Auto-generated method stub
Customer customer = new Customer();
customer.storefront();
customer.start("120.0.0.6", 9999);
	
		
		
		
		}

	public PrintWriter getOut() {
		return out;
	}

	public void setOut(PrintWriter out) {
		this.out = out;
	}

	public BufferedReader getIn() {
		return in;
	}

	public void setIn(BufferedReader in) {
		this.in = in;
	}

}
