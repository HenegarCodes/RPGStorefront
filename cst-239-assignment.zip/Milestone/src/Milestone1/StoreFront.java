package Milestone1;
import java.util.Scanner;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.InputMismatchException;

public class StoreFront  {
	
	
	
	
	//private static final String ShoppingCart = null;
	private static int knifePurchase = 0;
	private static int starPurchase = 0;
	private static int chainPurchase = 0;
	private static int bandagePurchase = 0;
	private static int medicPurchase = 0;
	private static int m69Purchase= 0;
	
	
	//store front menu
	
	

	
	
	
	public static void main(String[] args) throws UnknownHostException, IOException{
		// TODO Auto-generated method stub
		try {
		Scanner input = new Scanner(System.in);
		System.out.print("Welcome to Spencer's Arena Store!" 
		+ "\n-----------------------------------"
		+ "\n\nWhat would you like to do? (1-3)"
		+ "\n\t1. View Inventory" 
		+ "\n\t2. purchase an item"
		+ "\n\t3. View Shopping Cart " 
		+ "\n\t4. Return a product");
		byte selection = input.nextByte();
		
		if(selection == 1)
			Inventory.Inventory(); //Views Products
		else if (selection== 2)
			Product();
		else if (selection ==3)
			ShoppingCart.shoppingCart();//checkout with current cart
		else if (selection ==4);
			returnProduct();
		}catch(InputMismatchException e) {
			System.out.println("Invalid input. Try again");
			main(null);
		}
	}
		
		
		
	

		//Product/category menu
		static void Product() {
			try {
			Scanner input = new Scanner(System.in);
			System.out.print("Please select a weapon to view details: (1-4)"
					+ "\n\t1. Weapons"
					+ "\n\t2. Armor"
					+ "\n\t3. Health"
					+ "\n\t4. Back to menu");
			byte select = input.nextByte();
			
			if(select == 1)
				Weapons();
			else if (select == 2)
				Armor();
			else if(select == 3)
				Heal();
			else
				try {
				StoreFront.main(null);
			}catch(UnknownHostException e) {
				e.printStackTrace();
			}catch (IOException e) {
				e.printStackTrace();
			}
			}
			
			catch(InputMismatchException e) {
				System.out.println("Invalid input. Try again");
				Product();
			}
		}
		
		
		static void Weapons() {
		try {
			Scanner input = new Scanner(System.in);
			System.out.print("Please select a weapon to view details: (1-3)"
					+ "\n\t1. Throwing knife"+ "\n\t2. Ninja stars"+ "\n\t3. Cancel Purchase");
			byte wpn = input.nextByte();
			
			if(wpn == 1) { //will call knife from salable product class
				
				Scanner quantInS = new Scanner(System.in);
				System.out.println("How many knifes would you like to purchase? ");
				knifePurchase += quantInS.nextInt();
				try {
					StoreFront.main(null);
				}catch (UnknownHostException e) {
					e.printStackTrace();
				}catch (IOException e) {
					e.printStackTrace();
				}
			}
			else if (wpn == 2) {
				Scanner quantInTS = new Scanner(System.in);
					System.out.println("How many Ninja Stars would you like to purchase? ");
				starPurchase += quantInTS.nextInt();
				
				try {
					StoreFront.main(null);
				}catch (UnknownHostException e) {
					e.printStackTrace();
				}catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			
				
		else{//if does not want anything return to main menu
							System.out.println("Invalid input");
					Product();
		}} catch(InputMismatchException e) {
						System.out.println("Invalid input. Try again");
						Product();
					}}
					



	static void Heal() {
		try{
	
	Scanner input = new Scanner(System.in);
	System.out.print("Please select an armor type to view details: (1-3)"
			+ "\n\t1. bandage"+ "\n\t2. medic"+ "\n\t3. Cancel Purchase");
	byte heal = input.nextByte();
	
	if(heal == 1) {
		Scanner quantInS = new Scanner(System.in);
		System.out.println("How many Bandages would you like to purchase?");
		bandagePurchase += quantInS.nextInt();
		try {
			StoreFront.main(null);
		}catch (UnknownHostException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
	}
		
	else if (heal == 2) {
		Scanner quantInTs = new Scanner(System.in);
				System.out.println("How many Medic would you like purchase?");
				medicPurchase += quantInTs.nextInt();
				try {
					StoreFront.main(null);
				}catch (UnknownHostException e) {
					e.printStackTrace();
				}catch (IOException e) {
					e.printStackTrace();
				}
			}
			
	
	else {
		System.out.println("Invalid input");
		Product();
	}}catch(InputMismatchException e) {
		System.out.println("Invalid input. Try again");
		Product();
	}
	}
	
	
	
	
		static void Armor() {
			try {
			Scanner input = new Scanner(System.in);
			System.out.print("Please select an armor type to view details: (1-3)"
					+ "\n\t1. M69"+ "\n\t2. Chain"+ "\n\t3. Cancel Purchase");
			byte arm = input.nextByte();
			
			if(arm == 1) {
				Scanner quantInMedic = new Scanner(System.in);
						System.out.println("How many M69 do you want to purchase? ");
						m69Purchase += quantInMedic.nextInt();
						
						try {
							StoreFront.main(null);
						}catch (UnknownHostException e) {
							e.printStackTrace();
						}catch (IOException e) {
							e.printStackTrace();
						}
			}
			else if (arm == 2) {
				Scanner quantInChain = new Scanner(System.in);
				System.out.println("How many chains do you want to purchase?");
				chainPurchase += quantInChain.nextInt();
				
				try {
					StoreFront.main(null);
				}catch (UnknownHostException e) {
					e.printStackTrace();
				}catch (IOException e) {
					e.printStackTrace();
				}
			}
			else {
				System.out.println("invalid input");
				Product();
			}}catch(InputMismatchException e) {
				System.out.println("Invalid input. Try again");
				Product();
			}}
			

public static void returnProduct() throws UnknownHostException, IOException {
	System.out.println("Select an item to return from your shopping cart (1-6): "
		+ "\n1. Machete"
		+ "\n2. Ninja Star"
		+ "\n3. Chainmail"
		+ "\n4. M69"
		+ "\n5. Bandage"
		+ "\n6. Medic");
	Scanner input = new Scanner(System.in);
	byte in = input.nextByte();
	
	try {
		if (in == 1)
			knifePurchase-=knifePurchase;
		else if(in ==2)
			starPurchase -= starPurchase;
		else if(in == 3)
			chainPurchase -= chainPurchase;
		else if (in == 4)
			m69Purchase -= m69Purchase;
		else if(in == 5)
			bandagePurchase -= bandagePurchase;
		else returnProduct();
	}catch(InputMismatchException e) {
		System.out.println("Invalid input. Try agan.");
		returnProduct();
	}StoreFront.main(null);

}



		//Health menu

		














public static int getKnifePurchase() {
	return knifePurchase;
}
public static void setKnifePurchase(int knifePurchase) {
	StoreFront.knifePurchase = knifePurchase;
}

public static int getStarPurchase () {
	return starPurchase ;
}
public void setStarPurchase(int starPurchase) {
	StoreFront.starPurchase = starPurchase;
}

public static int getM69Purchase() {
	return m69Purchase;
}
public void setM69Purchase(int m69Purchase) {
	StoreFront.m69Purchase = m69Purchase;
}

public static int getChainPurchase() {
	return chainPurchase;
}
public void setChainPurchase(int chainPurchase) {
	StoreFront.chainPurchase = chainPurchase;
}


public static int getBandagePurchase() {
	return bandagePurchase;
}
public void setBandagePurchase(int bandagePurchase) {
	StoreFront.bandagePurchase = bandagePurchase;
}

public static int getMedicPurchase() {
	return medicPurchase;
}
public void setMedicPurchase(int medicPurchase) {
	StoreFront.medicPurchase = medicPurchase;
}





public static void menu() {
	// TODO Auto-generated method stub
	
}

	




}



		
	
		
		
		
	




		
	


