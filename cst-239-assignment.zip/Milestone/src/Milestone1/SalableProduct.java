package Milestone1;

import java.text.DecimalFormat;
import java.util.Scanner;

public class SalableProduct {
static String name;
static String description;
static float price;
static int quantity;
public static final DecimalFormat df = new DecimalFormat("0.00");
public static int getKnifePurchase() {
	// TODO Auto-generated method stub
	return 0;
}
public static int getStarPurchase() {
	// TODO Auto-generated method stub
	return 0;
}
public static int getM69Purchase() {
	// TODO Auto-generated method stub
	return 0;
}
public static int getChainPurchase() {
	// TODO Auto-generated method stub
	return 0;
}
public static int getBandagePurchase() {
	// TODO Auto-generated method stub
	return 0;
}
public static int getMedicPurchase() {
	// TODO Auto-generated method stub
	return 0;
}








//armor menu


}