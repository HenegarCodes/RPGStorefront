package Milestone1;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Collections;
import java.util.Iterator;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Inventory {
	
	
	private static void displayProduct(Salable product) {
		System.out.println(product.getDescription() + "| " 
	+ product. getName() + " | $" + product.getPrice() + " | " + product.getQuantity());
	}
	
	
	public static void Inventory() throws UnknownHostException, IOException {
		int invKnife = 50 - StoreFront.getKnifePurchase();
		int invTS = 250 - StoreFront.getStarPurchase();
		int invChain = 150 - StoreFront.getChainPurchase();
		int invM69 = 100 - StoreFront.getM69Purchase();
		int invBandage = 250 - StoreFront.getBandagePurchase();
		int invMedic = 400 - StoreFront.getMedicPurchase();
	
	
	
ArrayList<Salable> inventory = new ArrayList<Salable>();
inventory.add(new Weapons("Machete", "Weapon", 50.00, invKnife));
inventory.add(new Weapons("Ninja Star", "Weapon", 10.00, invTS));
inventory.add(new Armor("ChainMail", "Armor", 200.00, invChain));
inventory.add(new Armor("M69", "Armor", 300.00, invM69));
inventory.add(new Health("Bandage", "Health", 100.00, invBandage));
inventory.add(new Health("Medic", "Health", 200.00, invMedic));

Scanner sort = new Scanner(System.in);
System.out.println("----------------"+ "\nEnter 1 to sort by name ascending, 2 for name descending,"
+ " 3 to sort by price ascending, 4 for price descending"
+" \n0r 0 to return to Main Menu");
byte inSort = sort.nextByte();

if(inSort == 1) {
	Collections.sort(inventory, Salable.nameUPComparator);
	Iterator<Salable> iterator = inventory.iterator();
	while(iterator.hasNext());{
}
Inventory();
	}
else if(inSort == 2) {
	Collections.sort(inventory, Salable.nameDOWNComparator);
	Iterator<Salable>iterator = inventory.iterator();
	while(iterator.hasNext()) {
		displayProduct(iterator.next());
	}
Inventory();

}
else if (inSort == 3) {
	Collections.sort(inventory, Salable.priceUPComparator);
	Iterator<Salable> iterator = inventory.iterator();
	while(iterator.hasNext()) {
		displayProduct(iterator.next());
	}
Inventory();
}

else if(inSort == 4) {
	Collections.sort(inventory, Salable.priceDOWNComparator);
	Iterator<Salable> iterator = inventory.iterator();
	while(iterator.hasNext()) {
		displayProduct(iterator.next());
	}
	Inventory();
}
else 
	StoreFront.main(null);

System.out.println("Description | Name | Price | Quantity");

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
