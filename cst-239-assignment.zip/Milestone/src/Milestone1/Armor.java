package Milestone1;

public class Armor extends Salable {

	
	
	public Armor(String name, String description, double price, int quantity)
	{
		super(name, description, price, quantity);
	}


	

	
	
}
