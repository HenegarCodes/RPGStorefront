package Milestone1;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Admin {
	
	
	private Socket adminSocket;
	
	public void start(String ip, int port) throws UnknownHostException, IOException {
		setAdminSocket(new Socket(ip, port));
	}
	
	public void greeting() throws UnknownHostException, IOException {
		System.out.println("Welcome Admin"
				+ "\nType 'U' to Update Inventory"
				+ "\nType 'R' to see current inventory in JSON format");
	
		Scanner input = new Scanner(System.in);
		String in =(input.next());
		
		try {
			if(in == "U" || in == "u") {
				
			}else if (in == "R" || in =="r") {
				
			}else greeting();
		}catch(InputMismatchException e) {
			e.printStackTrace();
			System.out.println("Invalid input. Try again");
			greeting();
		}
	
	}
	

	public static void main(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub
		Admin admin = new Admin();
		admin.greeting();
		admin.start("120.0.0.6", 9999);
	}

	public Socket getAdminSocket() {
		return adminSocket;
	}

	public void setAdminSocket(Socket adminSocket) {
		this.adminSocket = adminSocket;
	}

}
