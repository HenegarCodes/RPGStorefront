package Milestone1;

import java.util.Scanner;

public class InventoryManager {

	static int quantityKnife = 25;
	static int quantityTS = 300;
	static int quantityM69 = 400;
	static int quantityChain = 700;
	static int quantityBandage = 100;
	static int quantityMedic = 5;


	public static void InventoryDisplay() {
		Scanner input = new Scanner(System.in);
		System.out.println("Current stick: " + "\n1. Weapons:" + 
		"\n\ta.Knifes: " + quantityKnife + "\n\tb. Ninja Stars: " + 
		quantityTS + "\n2. Armor:" + "\n\ta.Chain: " + quantityChain + 
		"\n\tb.M69: " + quantityM69 + "\n3. Health:" + "\n\ta.Bandage: " + 
		quantityBandage + "\n\tb.Medic: " + quantityMedic + "\nTypeany number to return to the Main Menu");
	
	
	byte select = input.nextByte();
	if (select == 1)
		StoreFront.menu();
	else
		StoreFront.menu();
	}
	
	
	//rmeoveitems form inventory
	
	public static void removeKnife(int knifePurchase) {
		quantityKnife -= knifePurchase;
	}
	
	public static void removeTS(int tSPurchase) {
		quantityTS -= tSPurchase;
	}
	
	public static void removeM69(int m69Purchase) {
		quantityM69 -= m69Purchase;
	}
	
	public static void removeChain(int chainPurchase) {
		quantityChain -= chainPurchase;
	}
	
	public static void removeBandage(int bandagePurchase) {
		quantityBandage -= bandagePurchase;
	}
	
	public static void removeMedic(int medicPurchase) {
		quantityMedic -= medicPurchase;
	}
	
	public static void returnKnife(int knifePurchase) {
		quantityKnife += knifePurchase;
	}
	
	public static void returnTS(int tSPurchase) {
		quantityTS += tSPurchase;
	}
	
	public static void returnM69(int m69Purchase) {
		quantityM69 += m69Purchase;
	}
	
	public static void returnChain(int chainPurchase) {
		quantityChain += chainPurchase;
	}
	
	public static void returnBandage(int bandagePurchase) {
		quantityBandage += bandagePurchase;
	}
	
	public static void returnMedic(int medicPurchase) {
		quantityMedic += medicPurchase;
	}
	
	
	
	
	public static int getQuantityKnife() {
		return quantityKnife;
	}
	public void setQuantityKnife(int quantityKnife) {
		InventoryManager.quantityKnife = quantityKnife;
	}
	
	
	
	public static int getQuantityTS() {
		return quantityTS;
	}
	public void setQuantityTS(int quantityTS) {
		InventoryManager.quantityTS = quantityTS;
	}
	
	//added armor/health for getters/setters for armor here
	public static int getQuantityM69() {
		return quantityM69;
	}
	public void setQuantityM69(int quantityM69) {
		InventoryManager.quantityM69 = quantityM69;
	}
	
	
	public static int getQuantityChain() {
		return quantityChain;
	}
	public void setQuantityChain(int quantityChain) {
		InventoryManager.quantityChain = quantityChain;
	}
	
	
	public static int getQuantityBandage() {
		return quantityBandage;
	}
	public void setQuantityBandage(int quantityBandage) {
		InventoryManager.quantityBandage= quantityBandage;
	}
	
	
	public static int getQuantityMedic() {
		return quantityMedic;
	}
	public void setQuantityMedic(int quantityMedic) {
		InventoryManager.quantityMedic= quantityMedic;
	}
	

	


	


	
}
